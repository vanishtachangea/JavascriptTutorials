/*eslint-env browser*/

var $ = function (id) {
    "use strict";
    return window.document.getElementById(id);
};

window.addEventListener("load", function () {
    "use strict";
    var xhr, xmlDoc, team, i;
    
    xhr = new XMLHttpRequest();
    xhr.open("GET", "data/team.xml");
    xhr.send();
    xhr.addEventListener("readystatechange", function () {
        if (xhr.status === 200) {
            xmlDoc = xhr.responseXML;
            team = xmlDoc.getElementsByTagName("teammember");
            for (i = 0; i < team.length; i += 1) {
                $("team").innerHTML += xmlDoc.getElementsByTagName("name")[i].childNodes[0].nodeValue + "<br>" + 
                    xmlDoc.getElementsByTagName("title")[i].childNodes[0].nodeValue + "<br>" + 
                    xmlDoc.getElementsByTagName("bio")[i].childNodes[0].nodeValue + "<br><br>"; 
            }
        } else {
            window.alert("There was an error connecting to the document.");
        }
    });
});